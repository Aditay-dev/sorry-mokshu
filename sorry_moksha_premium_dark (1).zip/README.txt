SORRY MOKSHA — PREMIUM DARK EDITION

Preview locally:
Keep index.html and moksha-photo.jpeg in the same folder. Double-click index.html.

Publish without asking visitors to log in:
Use GitHub Pages (free):
1. Sign in/create a GitHub account at https://github.com
2. Create a new PUBLIC repository, e.g. sorry-mokshu
3. Upload both index.html and moksha-photo.jpeg to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the published URL shown on the Pages screen (usually https://YOUR-USERNAME.github.io/REPOSITORY-NAME/).
7. Open the URL in an incognito/private browser to confirm it works without a login, then send it to Moksha.

Visitors do not need a GitHub account. Only you need an account to publish/update the site.
